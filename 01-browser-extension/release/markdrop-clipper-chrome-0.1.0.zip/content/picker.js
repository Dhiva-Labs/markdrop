(()=>{function ee(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e}function E(e,t){return Array(t+1).join(e)}function M(e){return e.replace(/^\n*/,"")}function $(e){for(var t=e.length;t>0&&e[t-1]===`
`;)t--;return e.substring(0,t)}function I(e){return $(M(e))}var te=["ADDRESS","ARTICLE","ASIDE","AUDIO","BLOCKQUOTE","BODY","CANVAS","CENTER","DD","DIR","DIV","DL","DT","FIELDSET","FIGCAPTION","FIGURE","FOOTER","FORM","FRAMESET","H1","H2","H3","H4","H5","H6","HEADER","HGROUP","HR","HTML","ISINDEX","LI","MAIN","MENU","NAV","NOFRAMES","NOSCRIPT","OL","OUTPUT","P","PRE","SECTION","TABLE","TBODY","TD","TFOOT","TH","THEAD","TR","UL"];function C(e){return x(e,te)}var H=["AREA","BASE","BR","COL","COMMAND","EMBED","HR","IMG","INPUT","KEYGEN","LINK","META","PARAM","SOURCE","TRACK","WBR"];function _(e){return x(e,H)}function ne(e){return U(e,H)}var F=["A","TABLE","THEAD","TBODY","TFOOT","TH","TD","IFRAME","SCRIPT","AUDIO","VIDEO"];function re(e){return x(e,F)}function ie(e){return U(e,F)}function x(e,t){return t.indexOf(e.nodeName)>=0}function U(e,t){return e.getElementsByTagName&&t.some(function(n){return e.getElementsByTagName(n).length})}var ae=[[/\\/g,"\\\\"],[/\*/g,"\\*"],[/^-/g,"\\-"],[/^\+ /g,"\\+ "],[/^(=+)/g,"\\$1"],[/^(#{1,6}) /g,"\\$1 "],[/`/g,"\\`"],[/^~~~/g,"\\~~~"],[/\[/g,"\\["],[/\]/g,"\\]"],[/^>/g,"\\>"],[/_/g,"\\_"],[/^(\d+)\. /g,"$1\\. "]];function V(e){return ae.reduce(function(t,n){return t.replace(n[0],n[1])},e)}var f={};f.paragraph={filter:"p",replacement:function(e){return`

`+e+`

`}};f.lineBreak={filter:"br",replacement:function(e,t,n){return n.br+`
`}};f.heading={filter:["h1","h2","h3","h4","h5","h6"],replacement:function(e,t,n){var r=Number(t.nodeName.charAt(1));if(n.headingStyle==="setext"&&r<3){var a=E(r===1?"=":"-",e.length);return`

`+e+`
`+a+`

`}else return`

`+E("#",r)+" "+e+`

`}};f.blockquote={filter:"blockquote",replacement:function(e){return e=I(e).replace(/^/gm,"> "),`

`+e+`

`}};f.list={filter:["ul","ol"],replacement:function(e,t){var n=t.parentNode;return n.nodeName==="LI"&&n.lastElementChild===t?`
`+e:`

`+e+`

`}};f.listItem={filter:"li",replacement:function(e,t,n){var r=n.bulletListMarker+"   ",a=t.parentNode;if(a.nodeName==="OL"){var i=a.getAttribute("start"),c=Array.prototype.indexOf.call(a.children,t);r=(i?Number(i)+c:c+1)+".  "}var u=/\n$/.test(e);return e=I(e)+(u?`
`:""),e=e.replace(/\n/gm,`
`+" ".repeat(r.length)),r+e+(t.nextSibling?`
`:"")}};f.indentedCodeBlock={filter:function(e,t){return t.codeBlockStyle==="indented"&&e.nodeName==="PRE"&&e.firstChild&&e.firstChild.nodeName==="CODE"},replacement:function(e,t,n){return`

    `+t.firstChild.textContent.replace(/\n/g,`
    `)+`

`}};f.fencedCodeBlock={filter:function(e,t){return t.codeBlockStyle==="fenced"&&e.nodeName==="PRE"&&e.firstChild&&e.firstChild.nodeName==="CODE"},replacement:function(e,t,n){for(var r=t.firstChild.getAttribute("class")||"",a=(r.match(/language-(\S+)/)||[null,""])[1],i=t.firstChild.textContent,c=n.fence.charAt(0),u=3,s=new RegExp("^"+c+"{3,}","gm"),d;d=s.exec(i);)d[0].length>=u&&(u=d[0].length+1);var m=E(c,u);return`

`+m+a+`
`+i.replace(/\n$/,"")+`
`+m+`

`}};f.horizontalRule={filter:"hr",replacement:function(e,t,n){return`

`+n.hr+`

`}};f.inlineLink={filter:function(e,t){return t.linkStyle==="inlined"&&e.nodeName==="A"&&e.getAttribute("href")},replacement:function(e,t){var n=w(t.getAttribute("href")),r=T(y(t.getAttribute("title"))),a=r?' "'+r+'"':"";return"["+e+"]("+n+a+")"}};f.referenceLink={filter:function(e,t){return t.linkStyle==="referenced"&&e.nodeName==="A"&&e.getAttribute("href")},replacement:function(e,t,n){var r=w(t.getAttribute("href")),a=y(t.getAttribute("title"));a&&(a=' "'+T(a)+'"');var i,c;switch(n.linkReferenceStyle){case"collapsed":i="["+e+"][]",c="["+e+"]: "+r+a;break;case"shortcut":i="["+e+"]",c="["+e+"]: "+r+a;break;default:var u=this.references.length+1;i="["+e+"]["+u+"]",c="["+u+"]: "+r+a}return this.references.push(c),i},references:[],append:function(e){var t="";return this.references.length&&(t=`

`+this.references.join(`
`)+`

`,this.references=[]),t}};f.emphasis={filter:["em","i"],replacement:function(e,t,n){return e.trim()?n.emDelimiter+e+n.emDelimiter:""}};f.strong={filter:["strong","b"],replacement:function(e,t,n){return e.trim()?n.strongDelimiter+e+n.strongDelimiter:""}};f.code={filter:function(e){var t=e.previousSibling||e.nextSibling,n=e.parentNode.nodeName==="PRE"&&!t;return e.nodeName==="CODE"&&!n},replacement:function(e){if(!e)return"";e=e.replace(/\r?\n|\r/g," ");for(var t=/^`|^ .*?[^ ].* $|`$/.test(e)?" ":"",n="`",r=e.match(/`+/gm)||[];r.indexOf(n)!==-1;)n=n+"`";return n+t+e+t+n}};f.image={filter:"img",replacement:function(e,t){var n=V(y(t.getAttribute("alt"))),r=w(t.getAttribute("src")||""),a=y(t.getAttribute("title")),i=a?' "'+T(a)+'"':"";return r?"!["+n+"]("+r+i+")":""}};function y(e){return e?e.replace(/(\n+\s*)+/g,`
`):""}function w(e){var t=e.replace(/([<>()])/g,"\\$1");return t.indexOf(" ")>=0?"<"+t+">":t}function T(e){return e.replace(/"/g,'\\"')}function W(e){this.options=e,this._keep=[],this._remove=[],this.blankRule={replacement:e.blankReplacement},this.keepReplacement=e.keepReplacement,this.defaultRule={replacement:e.defaultReplacement},this.array=[];for(var t in e.rules)this.array.push(e.rules[t])}W.prototype={add:function(e,t){this.array.unshift(t)},keep:function(e){this._keep.unshift({filter:e,replacement:this.keepReplacement})},remove:function(e){this._remove.unshift({filter:e,replacement:function(){return""}})},forNode:function(e){if(e.isBlank)return this.blankRule;var t;return(t=k(this.array,e,this.options))||(t=k(this._keep,e,this.options))||(t=k(this._remove,e,this.options))?t:this.defaultRule},forEach:function(e){for(var t=0;t<this.array.length;t++)e(this.array[t],t)}};function k(e,t,n){for(var r=0;r<e.length;r++){var a=e[r];if(oe(a,t,n))return a}}function oe(e,t,n){var r=e.filter;if(typeof r=="string"){if(r===t.nodeName.toLowerCase())return!0}else if(Array.isArray(r)){if(r.indexOf(t.nodeName.toLowerCase())>-1)return!0}else if(typeof r=="function"){if(r.call(e,t,n))return!0}else throw new TypeError("`filter` needs to be a string, array, or function")}function le(e){var t=e.element,n=e.isBlock,r=e.isVoid,a=e.isPre||function(b){return b.nodeName==="PRE"};if(!(!t.firstChild||a(t))){for(var i=null,c=!1,u=null,s=B(u,t,a);s!==t;){if(s.nodeType===3||s.nodeType===4){var d=s.data.replace(/[ \r\n\t]+/g," ");if((!i||/ $/.test(i.data))&&!c&&d[0]===" "&&(d=d.substr(1)),!d){s=A(s);continue}s.data=d,i=s}else if(s.nodeType===1)n(s)||s.nodeName==="BR"?(i&&(i.data=i.data.replace(/ $/,"")),i=null,c=!1):r(s)||a(s)?(i=null,c=!0):i&&(c=!1);else{s=A(s);continue}var m=B(u,s,a);u=s,s=m}i&&(i.data=i.data.replace(/ $/,""),i.data||A(i))}}function A(e){var t=e.nextSibling||e.parentNode;return e.parentNode.removeChild(e),t}function B(e,t,n){return e&&e.parentNode===t||n(t)?t.nextSibling||t.parentNode:t.firstChild||t.nextSibling||t.parentNode}var R=typeof window<"u"?window:{};function ce(){var e=R.DOMParser,t=!1;try{new e().parseFromString("","text/html")&&(t=!0)}catch{}return t}function se(){var e=function(){};return ue()?e.prototype.parseFromString=function(t){var n=new window.ActiveXObject("htmlfile");return n.designMode="on",n.open(),n.write(t),n.close(),n}:e.prototype.parseFromString=function(t){var n=document.implementation.createHTMLDocument("");return n.open(),n.write(t),n.close(),n},e}function ue(){var e=!1;try{document.implementation.createHTMLDocument("").open()}catch{R.ActiveXObject&&(e=!0)}return e}var fe=ce()?R.DOMParser:se();function de(e,t){var n;if(typeof e=="string"){var r=pe().parseFromString('<x-turndown id="turndown-root">'+e+"</x-turndown>","text/html");n=r.getElementById("turndown-root")}else n=e.cloneNode(!0);return le({element:n,isBlock:C,isVoid:_,isPre:t.preformattedCode?me:null}),n}var N;function pe(){return N=N||new fe,N}function me(e){return e.nodeName==="PRE"||e.nodeName==="CODE"}function he(e,t){return e.isBlock=C(e),e.isCode=e.nodeName==="CODE"||e.parentNode.isCode,e.isBlank=ge(e),e.flankingWhitespace=ve(e,t),e}function ge(e){return!_(e)&&!re(e)&&/^\s*$/i.test(e.textContent)&&!ne(e)&&!ie(e)}function ve(e,t){if(e.isBlock||t.preformattedCode&&e.isCode)return{leading:"",trailing:""};var n=be(e.textContent);return n.leadingAscii&&P("left",e,t)&&(n.leading=n.leadingNonAscii),n.trailingAscii&&P("right",e,t)&&(n.trailing=n.trailingNonAscii),{leading:n.leading,trailing:n.trailing}}function be(e){var t=e.match(/^(([ \t\r\n]*)(\s*))(?:(?=\S)[\s\S]*\S)?((\s*?)([ \t\r\n]*))$/);return{leading:t[1],leadingAscii:t[2],leadingNonAscii:t[3],trailing:t[4],trailingNonAscii:t[5],trailingAscii:t[6]}}function P(e,t,n){var r,a,i;return e==="left"?(r=t.previousSibling,a=/ $/):(r=t.nextSibling,a=/^ /),r&&(r.nodeType===3?i=a.test(r.nodeValue):n.preformattedCode&&r.nodeName==="CODE"?i=!1:r.nodeType===1&&!C(r)&&(i=a.test(r.textContent))),i}var ye=Array.prototype.reduce;function v(e){if(!(this instanceof v))return new v(e);var t={rules:f,headingStyle:"setext",hr:"* * *",bulletListMarker:"*",codeBlockStyle:"indented",fence:"```",emDelimiter:"_",strongDelimiter:"**",linkStyle:"inlined",linkReferenceStyle:"full",br:"  ",preformattedCode:!1,blankReplacement:function(n,r){return r.isBlock?`

`:""},keepReplacement:function(n,r){return r.isBlock?`

`+r.outerHTML+`

`:r.outerHTML},defaultReplacement:function(n,r){return r.isBlock?`

`+n+`

`:n}};this.options=ee({},t,e),this.rules=new W(this.options)}v.prototype={turndown:function(e){if(!Ne(e))throw new TypeError(e+" is not a string, or an element/document/fragment node.");if(e==="")return"";var t=z.call(this,new de(e,this.options));return ke.call(this,t)},use:function(e){if(Array.isArray(e))for(var t=0;t<e.length;t++)this.use(e[t]);else if(typeof e=="function")e(this);else throw new TypeError("plugin must be a Function or an Array of Functions");return this},addRule:function(e,t){return this.rules.add(e,t),this},keep:function(e){return this.rules.keep(e),this},remove:function(e){return this.rules.remove(e),this},escape:function(e){return V(e)}};function z(e){var t=this;return ye.call(e.childNodes,function(n,r){r=new he(r,t.options);var a="";return r.nodeType===3?a=r.isCode?r.nodeValue:t.escape(r.nodeValue):r.nodeType===1&&(a=Ae.call(t,r)),j(n,a)},"")}function ke(e){var t=this;return this.rules.forEach(function(n){typeof n.append=="function"&&(e=j(e,n.append(t.options)))}),e.replace(/^[\t\r\n]+/,"").replace(/[\t\r\n\s]+$/,"")}function Ae(e){var t=this.rules.forNode(e),n=z.call(this,e),r=e.flankingWhitespace;return(r.leading||r.trailing)&&(n=n.trim()),r.leading+t.replacement(n,e,this.options)+r.trailing}function j(e,t){var n=$(e),r=M(t),a=Math.max(e.length-n.length,t.length-r.length),i=`

`.substring(0,a);return n+i+r}function Ne(e){return e!=null&&(typeof e=="string"||e.nodeType&&(e.nodeType===1||e.nodeType===9||e.nodeType===11))}var X=/highlight-(?:text|source)-([a-z0-9]+)/;function Ee(e){e.addRule("highlightedCodeBlock",{filter:function(t){var n=t.firstChild;return t.nodeName==="DIV"&&X.test(t.className)&&n&&n.nodeName==="PRE"},replacement:function(t,n,r){var a=n.className||"",i=(a.match(X)||[null,""])[1];return`

`+r.fence+i+`
`+n.firstChild.textContent+`
`+r.fence+`

`}})}function Ce(e){e.addRule("strikethrough",{filter:["del","s","strike"],replacement:function(t){return"~"+t+"~"}})}var xe=Array.prototype.indexOf,we=Array.prototype.every,g={};g.tableCell={filter:["th","td"],replacement:function(e,t){return Y(e,t)}};g.tableRow={filter:"tr",replacement:function(e,t){var n="",r={left:":--",right:"--:",center:":-:"};if(L(t))for(var a=0;a<t.childNodes.length;a++){var i="---",c=(t.childNodes[a].getAttribute("align")||"").toLowerCase();c&&(i=r[c]||i),n+=Y(i,t.childNodes[a])}return`
`+e+(n?`
`+n:"")}};g.table={filter:function(e){return e.nodeName==="TABLE"&&L(e.rows[0])},replacement:function(e){return e=e.replace(`

`,`
`),`

`+e+`

`}};g.tableSection={filter:["thead","tbody","tfoot"],replacement:function(e){return e}};function L(e){var t=e.parentNode;return t.nodeName==="THEAD"||t.firstChild===e&&(t.nodeName==="TABLE"||Te(t))&&we.call(e.childNodes,function(n){return n.nodeName==="TH"})}function Te(e){var t=e.previousSibling;return e.nodeName==="TBODY"&&(!t||t.nodeName==="THEAD"&&/^\s*$/i.test(t.textContent))}function Y(e,t){var n=xe.call(t.parentNode.childNodes,t),r=" ";return n===0&&(r="| "),r+e+" |"}function Re(e){e.keep(function(n){return n.nodeName==="TABLE"&&!L(n.rows[0])});for(var t in g)e.addRule(t,g[t])}function Le(e){e.addRule("taskListItems",{filter:function(t){return t.type==="checkbox"&&t.parentNode.nodeName==="LI"},replacement:function(t,n){return(n.checked?"[x]":"[ ]")+" "}})}function K(e){e.use([Ee,Ce,Re,Le])}function Se({keepDataUris:e=!1}={}){let t=new v({headingStyle:"atx",hr:"---",bulletListMarker:"-",codeBlockStyle:"fenced",emDelimiter:"*"});return t.use(K),t.addRule("safeLinks",{filter:n=>n.nodeName==="A"&&n.getAttribute("href"),replacement:(n,r)=>{let a=r.getAttribute("href")||"",i="",c=a.match(/^([a-zA-Z][a-zA-Z0-9+.-]*):/);if(c&&(i=c[1].toLowerCase()),i&&!["http","https","file"].includes(i))return n;if(!n.trim())return"";let u=r.getAttribute("title"),s=u?` "${u.replace(/"/g,'\\"')}"`:"";return`[${n}](${a}${s})`}}),t.addRule("images",{filter:"img",replacement:(n,r)=>{let a=(r.getAttribute("alt")||"").replace(/\n/g," "),i=r.getAttribute("src")||r.getAttribute("data-src")||"";i.startsWith("data:")&&!e&&(i=i.split(",")[0]+"...");let c=r.getAttribute("title"),u=c?` "${c.replace(/"/g,'\\"')}"`:"";return i?`![${a}](${i}${u})`:a}}),t.addRule("checkboxes",{filter:n=>n.nodeName==="INPUT"&&n.getAttribute("type")==="checkbox",replacement:(n,r)=>r.hasAttribute("checked")?"[x] ":"[ ] "}),t}function G(e,t={}){let n=Se(t);return q(n.turndown(e))}function q(e){return e.split(/\r?\n/).map(t=>t.replace(/\s+$/,"")).join(`
`).replace(/\n{3,}/g,`

`).trim()}function De({title:e,source:t}){let n=["---"],r=(e||"").replace(/\n/g," ").trim();return r&&n.push(`title: ${r}`),n.push(`source: ${t}`),n.push(`converted: ${new Date().toISOString().slice(0,10)}`),n.push("generator: dhiva-labs/markdrop-clipper"),n.push("---"),n.join(`
`)}function Z({title:e,source:t,markdown:n,withFrontMatter:r=!0}){let a=q(n);return r?`${De({title:e,source:t})}

${a}
`:a+`
`}function Q(e,t="converted"){return((e||t).replace(/[^\w\d-]+/g,"-").replace(/^-+|-+$/g,"").slice(0,80)||t)+".md"}(()=>{if(window.__mdClipperPickerActive)return;window.__mdClipperPickerActive=!0;let e=2147483600,t=new Set,n=null,r=c("rgba(99,102,241,.25)","2px solid #6366f1"),a=document.createElement("style");a.textContent=`
    .md-clip-picked-outline { outline: 3px solid #12805c !important; outline-offset: 1px; }
    .md-clip-bar { position: fixed; z-index: ${e+2}; left: 50%; transform: translateX(-50%);
      bottom: 18px; background: #171b23; color: #e6e9ef; border-radius: 12px;
      padding: 10px 14px; font: 13px/1.4 system-ui, sans-serif; display: flex; gap: 10px;
      align-items: center; box-shadow: 0 8px 30px rgba(0,0,0,.45); }
    .md-clip-bar button { background: #6366f1; color: #fff; border: 0; border-radius: 8px;
      padding: 7px 14px; font: inherit; cursor: pointer; }
    .md-clip-bar button.secondary { background: #2a3040; }
  `,document.documentElement.appendChild(a);let i=document.createElement("div");i.className="md-clip-bar",i.innerHTML=`<span>Click a block to select \xB7 Shift-click adds more \xB7 </span>
    <button data-act="done">Convert</button>
    <button class="secondary" data-act="cancel">Cancel (Esc)</button>`,document.documentElement.appendChild(i);function c(o,l){let p=document.createElement("div");return p.style.cssText=`position:absolute; z-index:${e}; pointer-events:none; background:${o}; border:${l}; border-radius:4px; display:none;`,document.documentElement.appendChild(p),p}function u(o,l){let p=l.getBoundingClientRect();o.style.display="block",o.style.left=p.left+scrollX+"px",o.style.top=p.top+scrollY+"px",o.style.width=p.width+"px",o.style.height=p.height+"px"}function s(o){let l=o;for(;l&&l!==document.body&&(l.matches?.("a, span, b, i, em, strong, code, img, svg *")||(l.getBoundingClientRect?.().height??0)<14);)l=l.parentElement;return l&&l!==document.documentElement?l:null}function d(o){let l=s(document.elementFromPoint(o.clientX,o.clientY));if(!l||i.contains(l)){r.style.display="none",n=null;return}n=l,u(r,l)}function m(o){if(!i.contains(o.target)&&(o.preventDefault(),o.stopPropagation(),!!n)){if(!o.shiftKey){for(let l of t)l.classList.remove("md-clip-picked-outline");t.clear()}t.has(n)?(t.delete(n),n.classList.remove("md-clip-picked-outline")):(t.add(n),n.classList.add("md-clip-picked-outline"))}}function b(o){o.key==="Escape"&&S(),o.key==="Enter"&&D()}function S(){window.__mdClipperPickerActive=!1,document.removeEventListener("mousemove",d,!0),document.removeEventListener("click",m,!0),document.removeEventListener("keydown",b,!0);for(let o of t)o.classList.remove("md-clip-picked-outline");r.remove(),i.remove(),a.remove()}function D(){if(!t.size&&n&&t.add(n),!t.size)return;let o=document.implementation.createHTMLDocument("");for(let h of t){let O=h.cloneNode(!0);O.classList?.remove("md-clip-picked-outline"),o.body.appendChild(O)}for(let h of o.querySelectorAll("a[href]"))try{h.setAttribute("href",new URL(h.getAttribute("href"),location.href).href)}catch{}for(let h of o.querySelectorAll("img[src]"))try{h.setAttribute("src",new URL(h.getAttribute("src"),location.href).href)}catch{}let l=G(o.body.innerHTML),p=Z({title:document.title,source:location.href,markdown:l});J(p)}function J(o){i.innerHTML=`<span>${o.length.toLocaleString()} chars of Markdown \xB7 </span>
      <button data-act="copy">Copy</button>
      <button data-act="download">Download .md</button>
      <button class="secondary" data-act="cancel">Close</button>`,i.dataset.result="1",i.__doc=o,r.style.display="none",document.removeEventListener("mousemove",d,!0),document.removeEventListener("click",m,!0)}i.addEventListener("click",async o=>{let l=o.target?.dataset?.act;l&&(o.stopPropagation(),l==="cancel"&&S(),l==="done"&&D(),l==="copy"&&(await navigator.clipboard.writeText(i.__doc),o.target.textContent="Copied \u2713"),l==="download"&&(chrome.runtime.sendMessage({type:"md-download",filename:Q(document.title,"clip"),content:i.__doc}),o.target.textContent="Saved \u2713"))}),document.addEventListener("mousemove",d,!0),document.addEventListener("click",m,!0),document.addEventListener("keydown",b,!0)})();})();
