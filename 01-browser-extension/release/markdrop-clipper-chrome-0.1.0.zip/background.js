(()=>{function K(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e}function y(e,t){return Array(t+1).join(e)}function D(e){return e.replace(/^\n*/,"")}function O(e){for(var t=e.length;t>0&&e[t-1]===`
`;)t--;return e.substring(0,t)}function I(e){return O(D(e))}var z=["ADDRESS","ARTICLE","ASIDE","AUDIO","BLOCKQUOTE","BODY","CANVAS","CENTER","DD","DIR","DIV","DL","DT","FIELDSET","FIGCAPTION","FIGURE","FOOTER","FORM","FRAMESET","H1","H2","H3","H4","H5","H6","HEADER","HGROUP","HR","HTML","ISINDEX","LI","MAIN","MENU","NAV","NOFRAMES","NOSCRIPT","OL","OUTPUT","P","PRE","SECTION","TABLE","TBODY","TD","TFOOT","TH","THEAD","TR","UL"];function A(e){return N(e,z)}var B=["AREA","BASE","BR","COL","COMMAND","EMBED","HR","IMG","INPUT","KEYGEN","LINK","META","PARAM","SOURCE","TRACK","WBR"];function L(e){return N(e,B)}function X(e){return P(e,B)}var M=["A","TABLE","THEAD","TBODY","TFOOT","TH","TD","IFRAME","SCRIPT","AUDIO","VIDEO"];function G(e){return N(e,M)}function Y(e){return P(e,M)}function N(e,t){return t.indexOf(e.nodeName)>=0}function P(e,t){return e.getElementsByTagName&&t.some(function(r){return e.getElementsByTagName(r).length})}var q=[[/\\/g,"\\\\"],[/\*/g,"\\*"],[/^-/g,"\\-"],[/^\+ /g,"\\+ "],[/^(=+)/g,"\\$1"],[/^(#{1,6}) /g,"\\$1 "],[/`/g,"\\`"],[/^~~~/g,"\\~~~"],[/\[/g,"\\["],[/\]/g,"\\]"],[/^>/g,"\\>"],[/_/g,"\\_"],[/^(\d+)\. /g,"$1\\. "]];function $(e){return q.reduce(function(t,r){return t.replace(r[0],r[1])},e)}var c={};c.paragraph={filter:"p",replacement:function(e){return`

`+e+`

`}};c.lineBreak={filter:"br",replacement:function(e,t,r){return r.br+`
`}};c.heading={filter:["h1","h2","h3","h4","h5","h6"],replacement:function(e,t,r){var n=Number(t.nodeName.charAt(1));if(r.headingStyle==="setext"&&n<3){var i=y(n===1?"=":"-",e.length);return`

`+e+`
`+i+`

`}else return`

`+y("#",n)+" "+e+`

`}};c.blockquote={filter:"blockquote",replacement:function(e){return e=I(e).replace(/^/gm,"> "),`

`+e+`

`}};c.list={filter:["ul","ol"],replacement:function(e,t){var r=t.parentNode;return r.nodeName==="LI"&&r.lastElementChild===t?`
`+e:`

`+e+`

`}};c.listItem={filter:"li",replacement:function(e,t,r){var n=r.bulletListMarker+"   ",i=t.parentNode;if(i.nodeName==="OL"){var a=i.getAttribute("start"),o=Array.prototype.indexOf.call(i.children,t);n=(a?Number(a)+o:o+1)+".  "}var s=/\n$/.test(e);return e=I(e)+(s?`
`:""),e=e.replace(/\n/gm,`
`+" ".repeat(n.length)),n+e+(t.nextSibling?`
`:"")}};c.indentedCodeBlock={filter:function(e,t){return t.codeBlockStyle==="indented"&&e.nodeName==="PRE"&&e.firstChild&&e.firstChild.nodeName==="CODE"},replacement:function(e,t,r){return`

    `+t.firstChild.textContent.replace(/\n/g,`
    `)+`

`}};c.fencedCodeBlock={filter:function(e,t){return t.codeBlockStyle==="fenced"&&e.nodeName==="PRE"&&e.firstChild&&e.firstChild.nodeName==="CODE"},replacement:function(e,t,r){for(var n=t.firstChild.getAttribute("class")||"",i=(n.match(/language-(\S+)/)||[null,""])[1],a=t.firstChild.textContent,o=r.fence.charAt(0),s=3,l=new RegExp("^"+o+"{3,}","gm"),u;u=l.exec(a);)u[0].length>=s&&(s=u[0].length+1);var f=y(o,s);return`

`+f+i+`
`+a.replace(/\n$/,"")+`
`+f+`

`}};c.horizontalRule={filter:"hr",replacement:function(e,t,r){return`

`+r.hr+`

`}};c.inlineLink={filter:function(e,t){return t.linkStyle==="inlined"&&e.nodeName==="A"&&e.getAttribute("href")},replacement:function(e,t){var r=w(t.getAttribute("href")),n=T(d(t.getAttribute("title"))),i=n?' "'+n+'"':"";return"["+e+"]("+r+i+")"}};c.referenceLink={filter:function(e,t){return t.linkStyle==="referenced"&&e.nodeName==="A"&&e.getAttribute("href")},replacement:function(e,t,r){var n=w(t.getAttribute("href")),i=d(t.getAttribute("title"));i&&(i=' "'+T(i)+'"');var a,o;switch(r.linkReferenceStyle){case"collapsed":a="["+e+"][]",o="["+e+"]: "+n+i;break;case"shortcut":a="["+e+"]",o="["+e+"]: "+n+i;break;default:var s=this.references.length+1;a="["+e+"]["+s+"]",o="["+s+"]: "+n+i}return this.references.push(o),a},references:[],append:function(e){var t="";return this.references.length&&(t=`

`+this.references.join(`
`)+`

`,this.references=[]),t}};c.emphasis={filter:["em","i"],replacement:function(e,t,r){return e.trim()?r.emDelimiter+e+r.emDelimiter:""}};c.strong={filter:["strong","b"],replacement:function(e,t,r){return e.trim()?r.strongDelimiter+e+r.strongDelimiter:""}};c.code={filter:function(e){var t=e.previousSibling||e.nextSibling,r=e.parentNode.nodeName==="PRE"&&!t;return e.nodeName==="CODE"&&!r},replacement:function(e){if(!e)return"";e=e.replace(/\r?\n|\r/g," ");for(var t=/^`|^ .*?[^ ].* $|`$/.test(e)?" ":"",r="`",n=e.match(/`+/gm)||[];n.indexOf(r)!==-1;)r=r+"`";return r+t+e+t+r}};c.image={filter:"img",replacement:function(e,t){var r=$(d(t.getAttribute("alt"))),n=w(t.getAttribute("src")||""),i=d(t.getAttribute("title")),a=i?' "'+T(i)+'"':"";return n?"!["+r+"]("+n+a+")":""}};function d(e){return e?e.replace(/(\n+\s*)+/g,`
`):""}function w(e){var t=e.replace(/([<>()])/g,"\\$1");return t.indexOf(" ")>=0?"<"+t+">":t}function T(e){return e.replace(/"/g,'\\"')}function H(e){this.options=e,this._keep=[],this._remove=[],this.blankRule={replacement:e.blankReplacement},this.keepReplacement=e.keepReplacement,this.defaultRule={replacement:e.defaultReplacement},this.array=[];for(var t in e.rules)this.array.push(e.rules[t])}H.prototype={add:function(e,t){this.array.unshift(t)},keep:function(e){this._keep.unshift({filter:e,replacement:this.keepReplacement})},remove:function(e){this._remove.unshift({filter:e,replacement:function(){return""}})},forNode:function(e){if(e.isBlank)return this.blankRule;var t;return(t=g(this.array,e,this.options))||(t=g(this._keep,e,this.options))||(t=g(this._remove,e,this.options))?t:this.defaultRule},forEach:function(e){for(var t=0;t<this.array.length;t++)e(this.array[t],t)}};function g(e,t,r){for(var n=0;n<e.length;n++){var i=e[n];if(Z(i,t,r))return i}}function Z(e,t,r){var n=e.filter;if(typeof n=="string"){if(n===t.nodeName.toLowerCase())return!0}else if(Array.isArray(n)){if(n.indexOf(t.nodeName.toLowerCase())>-1)return!0}else if(typeof n=="function"){if(n.call(e,t,r))return!0}else throw new TypeError("`filter` needs to be a string, array, or function")}function J(e){var t=e.element,r=e.isBlock,n=e.isVoid,i=e.isPre||function(W){return W.nodeName==="PRE"};if(!(!t.firstChild||i(t))){for(var a=null,o=!1,s=null,l=R(s,t,i);l!==t;){if(l.nodeType===3||l.nodeType===4){var u=l.data.replace(/[ \r\n\t]+/g," ");if((!a||/ $/.test(a.data))&&!o&&u[0]===" "&&(u=u.substr(1)),!u){l=v(l);continue}l.data=u,a=l}else if(l.nodeType===1)r(l)||l.nodeName==="BR"?(a&&(a.data=a.data.replace(/ $/,"")),a=null,o=!1):n(l)||i(l)?(a=null,o=!0):a&&(o=!1);else{l=v(l);continue}var f=R(s,l,i);s=l,l=f}a&&(a.data=a.data.replace(/ $/,""),a.data||v(a))}}function v(e){var t=e.nextSibling||e.parentNode;return e.parentNode.removeChild(e),t}function R(e,t,r){return e&&e.parentNode===t||r(t)?t.nextSibling||t.parentNode:t.firstChild||t.nextSibling||t.parentNode}var x=typeof window<"u"?window:{};function Q(){var e=x.DOMParser,t=!1;try{new e().parseFromString("","text/html")&&(t=!0)}catch{}return t}function ee(){var e=function(){};return te()?e.prototype.parseFromString=function(t){var r=new window.ActiveXObject("htmlfile");return r.designMode="on",r.open(),r.write(t),r.close(),r}:e.prototype.parseFromString=function(t){var r=document.implementation.createHTMLDocument("");return r.open(),r.write(t),r.close(),r},e}function te(){var e=!1;try{document.implementation.createHTMLDocument("").open()}catch{x.ActiveXObject&&(e=!0)}return e}var re=Q()?x.DOMParser:ee();function ne(e,t){var r;if(typeof e=="string"){var n=ie().parseFromString('<x-turndown id="turndown-root">'+e+"</x-turndown>","text/html");r=n.getElementById("turndown-root")}else r=e.cloneNode(!0);return J({element:r,isBlock:A,isVoid:L,isPre:t.preformattedCode?ae:null}),r}var k;function ie(){return k=k||new re,k}function ae(e){return e.nodeName==="PRE"||e.nodeName==="CODE"}function le(e,t){return e.isBlock=A(e),e.isCode=e.nodeName==="CODE"||e.parentNode.isCode,e.isBlank=oe(e),e.flankingWhitespace=ce(e,t),e}function oe(e){return!L(e)&&!G(e)&&/^\s*$/i.test(e.textContent)&&!X(e)&&!Y(e)}function ce(e,t){if(e.isBlock||t.preformattedCode&&e.isCode)return{leading:"",trailing:""};var r=se(e.textContent);return r.leadingAscii&&S("left",e,t)&&(r.leading=r.leadingNonAscii),r.trailingAscii&&S("right",e,t)&&(r.trailing=r.trailingNonAscii),{leading:r.leading,trailing:r.trailing}}function se(e){var t=e.match(/^(([ \t\r\n]*)(\s*))(?:(?=\S)[\s\S]*\S)?((\s*?)([ \t\r\n]*))$/);return{leading:t[1],leadingAscii:t[2],leadingNonAscii:t[3],trailing:t[4],trailingNonAscii:t[5],trailingAscii:t[6]}}function S(e,t,r){var n,i,a;return e==="left"?(n=t.previousSibling,i=/ $/):(n=t.nextSibling,i=/^ /),n&&(n.nodeType===3?a=i.test(n.nodeValue):r.preformattedCode&&n.nodeName==="CODE"?a=!1:n.nodeType===1&&!A(n)&&(a=i.test(n.textContent))),a}var ue=Array.prototype.reduce;function m(e){if(!(this instanceof m))return new m(e);var t={rules:c,headingStyle:"setext",hr:"* * *",bulletListMarker:"*",codeBlockStyle:"indented",fence:"```",emDelimiter:"_",strongDelimiter:"**",linkStyle:"inlined",linkReferenceStyle:"full",br:"  ",preformattedCode:!1,blankReplacement:function(r,n){return n.isBlock?`

`:""},keepReplacement:function(r,n){return n.isBlock?`

`+n.outerHTML+`

`:n.outerHTML},defaultReplacement:function(r,n){return n.isBlock?`

`+r+`

`:r}};this.options=K({},t,e),this.rules=new H(this.options)}m.prototype={turndown:function(e){if(!me(e))throw new TypeError(e+" is not a string, or an element/document/fragment node.");if(e==="")return"";var t=F.call(this,new ne(e,this.options));return fe.call(this,t)},use:function(e){if(Array.isArray(e))for(var t=0;t<e.length;t++)this.use(e[t]);else if(typeof e=="function")e(this);else throw new TypeError("plugin must be a Function or an Array of Functions");return this},addRule:function(e,t){return this.rules.add(e,t),this},keep:function(e){return this.rules.keep(e),this},remove:function(e){return this.rules.remove(e),this},escape:function(e){return $(e)}};function F(e){var t=this;return ue.call(e.childNodes,function(r,n){n=new le(n,t.options);var i="";return n.nodeType===3?i=n.isCode?n.nodeValue:t.escape(n.nodeValue):n.nodeType===1&&(i=de.call(t,n)),U(r,i)},"")}function fe(e){var t=this;return this.rules.forEach(function(r){typeof r.append=="function"&&(e=U(e,r.append(t.options)))}),e.replace(/^[\t\r\n]+/,"").replace(/[\t\r\n\s]+$/,"")}function de(e){var t=this.rules.forNode(e),r=F.call(this,e),n=e.flankingWhitespace;return(n.leading||n.trailing)&&(r=r.trim()),n.leading+t.replacement(r,e,this.options)+n.trailing}function U(e,t){var r=O(e),n=D(t),i=Math.max(e.length-r.length,t.length-n.length),a=`

`.substring(0,i);return r+a+n}function me(e){return e!=null&&(typeof e=="string"||e.nodeType&&(e.nodeType===1||e.nodeType===9||e.nodeType===11))}var pe=Array.prototype.indexOf,he=Array.prototype.every,p={};p.tableCell={filter:["th","td"],replacement:function(e,t){return _(e,t)}};p.tableRow={filter:"tr",replacement:function(e,t){var r="",n={left:":--",right:"--:",center:":-:"};if(V(t))for(var i=0;i<t.childNodes.length;i++){var a="---",o=(t.childNodes[i].getAttribute("align")||"").toLowerCase();o&&(a=n[o]||a),r+=_(a,t.childNodes[i])}return`
`+e+(r?`
`+r:"")}};p.table={filter:function(e){return e.nodeName==="TABLE"&&V(e.rows[0])},replacement:function(e){return e=e.replace(`

`,`
`),`

`+e+`

`}};p.tableSection={filter:["thead","tbody","tfoot"],replacement:function(e){return e}};function V(e){var t=e.parentNode;return t.nodeName==="THEAD"||t.firstChild===e&&(t.nodeName==="TABLE"||ge(t))&&he.call(e.childNodes,function(r){return r.nodeName==="TH"})}function ge(e){var t=e.previousSibling;return e.nodeName==="TBODY"&&(!t||t.nodeName==="THEAD"&&/^\s*$/i.test(t.textContent))}function _(e,t){var r=pe.call(t.parentNode.childNodes,t),n=" ";return r===0&&(n="| "),n+e+" |"}function ve(e){return e.split(/\r?\n/).map(t=>t.replace(/\s+$/,"")).join(`
`).replace(/\n{3,}/g,`

`).trim()}function ke({title:e,source:t}){let r=["---"],n=(e||"").replace(/\n/g," ").trim();return n&&r.push(`title: ${n}`),r.push(`source: ${t}`),r.push(`converted: ${new Date().toISOString().slice(0,10)}`),r.push("generator: dhiva-labs/markdrop-clipper"),r.push("---"),r.join(`
`)}function j({title:e,source:t,markdown:r,withFrontMatter:n=!0}){let i=ve(r);return n?`${ke({title:e,source:t})}

${i}
`:i+`
`}function C(e,t="converted"){return((e||t).replace(/[^\w\d-]+/g,"-").replace(/^-+|-+$/g,"").slice(0,80)||t)+".md"}chrome.runtime.onInstalled.addListener(()=>{chrome.contextMenus.create({id:"convert-page",title:"Convert page to Markdown",contexts:["page"]}),chrome.contextMenus.create({id:"convert-selection",title:"Convert selection to Markdown",contexts:["selection"]}),chrome.contextMenus.create({id:"copy-image-md",title:"Copy image as Markdown",contexts:["image"]}),chrome.contextMenus.create({id:"pick-element",title:"Select element to convert\u2026",contexts:["page"]}),chrome.contextMenus.create({id:"convert-link",title:"Convert link target to Markdown (via API)",contexts:["link"]})});async function ye(e){let{apiUrl:t,apiKey:r}=await chrome.storage.sync.get({apiUrl:"",apiKey:""});if(!t){h("Set the Conversion API endpoint in Options first.");return}let n={"Content-Type":"application/json"};r&&(n["X-API-Key"]=r);let i=await fetch(`${t.replace(/\/$/,"")}/api/convert/url`,{method:"POST",headers:n,body:JSON.stringify({url:e})}),a=await i.json().catch(()=>({}));if(!i.ok||!a.ok){h(a.error||a.detail||`API error ${i.status}`);return}E(C(a.title,"linked"),a.markdown)}async function Ae(e){await chrome.scripting.executeScript({target:{tabId:e},files:["content/extract.js"]})}async function b(e,t){await Ae(e);let r=await chrome.tabs.sendMessage(e,{type:"md-extract",mode:t});if(!r||r.error){h(r?.error||"Conversion failed");return}let n=j({title:r.title,source:r.source,markdown:r.markdown});E(C(r.title),n)}function E(e,t){let r="data:text/markdown;charset=utf-8,"+encodeURIComponent(t);chrome.downloads.download({url:r,filename:e,saveAs:!0})}function h(e){chrome.action.setBadgeText({text:"!"}),chrome.action.setBadgeBackgroundColor({color:"#b42318"}),setTimeout(()=>chrome.action.setBadgeText({text:""}),4e3),console.warn("[MD Clipper]",e)}chrome.contextMenus.onClicked.addListener(async(e,t)=>{if(t?.id)try{if(e.menuItemId==="convert-page"&&await b(t.id,"article"),e.menuItemId==="convert-selection"&&await b(t.id,"selection"),e.menuItemId==="pick-element"&&await chrome.scripting.executeScript({target:{tabId:t.id},files:["content/picker.js"]}),e.menuItemId==="convert-link"&&e.linkUrl&&await ye(e.linkUrl),e.menuItemId==="copy-image-md"){let n=`![${(e.altText||"").replace(/\n/g," ")}](${e.srcUrl})`;await chrome.scripting.executeScript({target:{tabId:t.id},args:[n],func:i=>navigator.clipboard.writeText(i)})}}catch(r){h(String(r?.message||r))}});chrome.commands.onCommand.addListener(async(e,t)=>{e==="convert-article"&&t?.id&&await b(t.id,"article")});chrome.runtime.onMessage.addListener((e,t,r)=>{e?.type==="md-download"&&(E(e.filename||"converted.md",e.content||""),r({ok:!0}))});})();
